//
//  ViewController.swift
//  GheddaCalendar
//
//  Created by Techteam on 18/04/16.
//  Copyright © 2016 Techteam. All rights reserved.
//

import UIKit

class ViewController: UIViewController, FSCalendarDataSource, FSCalendarDelegate
{
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet var textFieldForDate: UITextField!
    
    @IBOutlet var buttonOpenCalendar: UIButton!
    
    let myString: String = "256"
    let myInt: Int? = 2
    
    
let datesWithCat = ["20150505","20150605","20150705","20150805","20150905","20151005","20151105","20151205",
    "20160106","20160206","20160306","20160406","20160506","20160606","20160706"]
    
    
    
    
    
      override func viewDidLoad() {
        super.viewDidLoad()
        calendar.scrollDirection = .Horizontal
        calendar.appearance.caseOptions = [.HeaderUsesUpperCase,.WeekdayUsesUpperCase]
        calendar.selectDate(calendar.dateWithYear(2015, month: 10, day: 10))
        
        calendar.hidden = true
        
        
        //        calendar.allowsMultipleSelection = true
        
        // Uncomment this to test month->week and week->month transition
        /*
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (Int64)(2.5 * Double(NSEC_PER_SEC))), dispatch_get_main_queue()) { () -> Void in
        self.calendar.setScope(.Week, animated: true)
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (Int64)(1.5 * Double(NSEC_PER_SEC))), dispatch_get_main_queue()) { () -> Void in
        self.calendar.setScope(.Month, animated: true)
        }
        }
        */
        
    }
    
    
    func minimumDateForCalendar(calendar: FSCalendar) -> NSDate {
        return calendar.dateWithYear(2015, month: 1, day: 1)
    }
    
    func maximumDateForCalendar(calendar: FSCalendar) -> NSDate {
        return calendar.dateWithYear(2016, month: 10, day: 31)
    }
    
    func calendar(calendar: FSCalendar, numberOfEventsForDate date: NSDate) -> Int {
        let day = calendar.dayOfDate(date)
        return day % 5 == 0 ? day/5 : 0;
    }
    
    func calendarCurrentPageDidChange(calendar: FSCalendar) {
        NSLog("change page to \(calendar.stringFromDate(calendar.currentPage))")
    }
    
    func calendar(calendar: FSCalendar, didSelectDate date: NSDate) {
        NSLog("calendar did select date \(calendar.stringFromDate(date))")
        
        self.textFieldForDate.text = calendar.stringFromDate(date)
        calendar.hidden = true
    }
    
    
    @IBAction func OpenCalendar(sender: AnyObject)
    {
        

        
        if  calendar.hidden
        {
        
        calendar.hidden = false
        
        }
        else
        {
        
         calendar.hidden = true
        
        }
        
    }
    
    
    
//    func calendar(calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool) {
//        calendarHeightConstraint.constant = bounds.height
//        view.layoutIfNeeded()
//    }
//    
    func calendar(calendar: FSCalendar, imageForDate date: NSDate) -> UIImage? {
        return [13,24].containsObject(calendar.dayOfDate(date)) ? UIImage(named: "icon_cat") : nil
    }




}

